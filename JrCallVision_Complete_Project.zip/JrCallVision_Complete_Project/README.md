# Jr Call Vision — Android starter project

This is a complete **starter source project**, not a finished commercial caller-ID service or ready-to-install APK.

## Included
- Kotlin + Jetpack Compose Android project structure
- Black-and-gold dashboard
- Home, History, Location and Settings navigation
- Phone-number entry demo
- Android call-screening role request
- A call-screening service that currently allows calls to ring

## Not yet implemented
- Caller-name lookup database or provider
- Verified spam-reputation service
- Persistent call history
- Live location sharing
- Cloud backend, user accounts, production privacy/security review
- APK signing and Play Store publishing

A phone number does not reveal a person's exact live GPS location. Location sharing must be voluntary and explicitly consent-based.

## Build requirements
- Android Studio
- JDK 17
- Android SDK 35
- Gradle 8.9 or compatible with Android Gradle Plugin 8.7.3

Open this folder in Android Studio and allow Gradle sync. Android Studio can generate the Gradle wrapper if needed. Then use Build > Build Bundle(s) / APK(s) > Build APK(s).

The app uses package name `com.jrcallvision.app`.
