package com.jrcallvision.app.calls

import android.telecom.Call
import android.telecom.CallScreeningService
import android.util.Log

class VisionCallScreeningService : CallScreeningService() {
    override fun onScreenCall(callDetails: Call.Details) {
        val number = callDetails.handle?.schemeSpecificPart.orEmpty()
        Log.i("JrCallVision", "Incoming call screening event. Number available: ${number.isNotBlank()}")

        // This starter allows the call to ring. It does not identify or block callers yet.
        val response = CallResponse.Builder()
            .setDisallowCall(false)
            .setRejectCall(false)
            .setSkipCallLog(false)
            .setSkipNotification(false)
            .build()

        respondToCall(callDetails, response)
    }
}
