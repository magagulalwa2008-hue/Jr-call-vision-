package com.jrcallvision.app

import android.app.role.RoleManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Gold = Color(0xFFD6AC55)
private val Dark = Color(0xFF101010)
private val CardDark = Color(0xFF1D1D1D)
private val Muted = Color(0xFFAAAAAA)

class MainActivity : ComponentActivity() {
    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            Toast.makeText(this, "Call screening permission request completed.", Toast.LENGTH_SHORT).show()
        }

    private fun requestCallerIdRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val manager = getSystemService(RoleManager::class.java)
            if (manager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
                if (!manager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                    roleLauncher.launch(manager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
                } else {
                    Toast.makeText(this, "Jr Call Vision already has call-screening role.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Call screening is unavailable on this device.", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "Call screening requires Android 10 or newer.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JrTheme {
                JrCallVisionApp(onEnableCallerId = { requestCallerIdRole() })
            }
        }
    }
}

@Composable
private fun JrTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            background = Dark,
            surface = CardDark,
            onPrimary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
private fun JrCallVisionApp(onEnableCallerId: () -> Unit) {
    var tab by rememberSaveable { mutableStateOf("Home") }
    Scaffold(
        containerColor = Dark,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF181818)) {
                val items = listOf(
                    Triple("Home", Icons.Default.Home, "Home"),
                    Triple("History", Icons.Default.History, "History"),
                    Triple("Location", Icons.Default.LocationOn, "Location"),
                    Triple("Settings", Icons.Default.Settings, "Settings")
                )
                items.forEach { (name, icon, label) ->
                    NavigationBarItem(
                        selected = tab == name,
                        onClick = { tab = name },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Gold,
                            selectedTextColor = Gold,
                            indicatorColor = Color(0xFF39301E),
                            unselectedIconColor = Muted,
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { padding ->
        when (tab) {
            "Home" -> HomeScreen(onEnableCallerId, Modifier.padding(padding))
            "History" -> InfoPage("Call History", "Call history storage is not connected yet.", Icons.Default.History, Modifier.padding(padding))
            "Location" -> InfoPage("Location Sharing", "Location sharing is not connected. It must remain optional and require the other person's explicit consent.", Icons.Default.LocationOn, Modifier.padding(padding))
            else -> InfoPage("Settings", "Privacy and caller-identification settings will be added here.", Icons.Default.Settings, Modifier.padding(padding))
        }
    }
}

@Composable
private fun HomeScreen(onEnableCallerId: () -> Unit, modifier: Modifier = Modifier) {
    var number by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf("") }

    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(54.dp).background(Color(0xFF302719), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Call, contentDescription = null, tint = Gold, modifier = Modifier.size(27.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("JR CALL VISION", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("SMART CALLER IDENTIFICATION", color = Muted, fontSize = 10.sp)
            }
        }

        Column {
            Text("Welcome Back", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("Know who's calling. Stay informed.", color = Muted, fontSize = 14.sp)
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF292216)), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.Shield, contentDescription = null, tint = Gold, modifier = Modifier.size(35.dp))
                Text("Caller Protection", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Request Android's call-screening role to enable supported incoming-call screening.", color = Color.White, fontSize = 13.sp)
                Button(
                    onClick = onEnableCallerId,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)
                ) {
                    Icon(Icons.Default.Call, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Enable Caller ID")
                }
            }
        }

        Text("SEARCH A PHONE NUMBER", color = Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        OutlinedTextField(
            value = number,
            onValueChange = { number = it; message = "" },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Enter phone number") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(15.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Gold,
                unfocusedBorderColor = Muted,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                cursorColor = Gold
            )
        )
        Button(
            onClick = {
                message = if (number.trim().length >= 4)
                    "Number entered. A trusted caller-information database must be connected to look it up."
                else "Please enter a phone number."
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)
        ) {
            Icon(Icons.Default.Search, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Search Number")
        }
        if (message.isNotEmpty()) Text(message, color = Gold, fontSize = 13.sp)

        Text("YOUR FEATURES", color = Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        FeatureCard(Icons.Default.PersonSearch, "Caller Identification", "Display caller details from available trusted sources.")
        FeatureCard(Icons.Default.Warning, "Spam Awareness", "Show warnings when a number is verified as potentially unwanted.")
        FeatureCard(Icons.Default.LocationOn, "Location Sharing", "Optional sharing only with clear permission and consent.")
        Text("JR CALL VISION • BUILDING THE FUTURE", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun FeatureCard(icon: ImageVector, title: String, description: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardDark),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Gold, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(15.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(description, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun InfoPage(title: String, description: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = Gold, modifier = Modifier.size(55.dp))
        Spacer(Modifier.height(20.dp))
        Text(title, color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(description, color = Muted, fontSize = 14.sp)
    }
}
